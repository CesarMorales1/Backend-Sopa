import { check } from "express-validator";
import { validateResult } from "../utils/handleError.js";
const validateCreateUser = [
//nombre_usuario email foto_perfil google_id
    check('nombre_usuario')
    .exists()
    .notEmpty(),
    check('email')
    .exists()
    .notEmpty()
    .isEmail(),
    check('foto_perfil')
    .exists()
    .notEmpty()
    .isURL(),
    check('google_id')
    .exists()
    .notEmpty()
    .isString(),
    (req,res,next) => 
    {
        validateResult(req,res,next)
    }
]

export {validateCreateUser};