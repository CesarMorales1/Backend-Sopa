import { validationResult } from "express-validator";

const validateResult = (req,res,next) => 
{
    try
    {
        validationResult(req).throw()
        return next()
    }catch(err) 
    {
        res.status(400)
        // res.send({errors: err.array() })
        res.send('Una de las siguientes keys se encuentra esta perdida o vacia "nombre_usuario" "email" "foto_perfil" "google_id"')
    }
}

export 
{
    validateResult
}